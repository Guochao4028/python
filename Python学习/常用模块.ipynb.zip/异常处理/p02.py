# try:
#     print("i am")
#     print(3.14)
#     #手动引发一个异常
#     raise ValueError
#     print("no has")
# except NameError as e:
#     print("NameError")
# except ValueError as e:
#     print("ValueError")
# except Exception as e:
#     print("Exception")
# finally:
#     print("end")

# # 自定义异常
# # 需要注意：自定义异常必须是系统异常的子类
# class DanaError(Exception):
#     pass
# try:
#     print("i a")
#     raise DanaError
# # except DanaError as e:
# #     print("da")
# except Exception as e:
#     print("ex")


