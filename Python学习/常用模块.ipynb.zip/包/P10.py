from pkg02 import *

p01.say()

# inInto()