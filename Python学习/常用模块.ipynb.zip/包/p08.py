import  pkg01.p01
pkg01.p01.getName()
stu = pkg01.p01.Stusent()
stu.say()
print("name:{0}, age:{1}".format(stu.name,stu.age))