def say():
    print("pkg02.p01")