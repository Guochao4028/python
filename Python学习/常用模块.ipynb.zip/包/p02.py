import p01

stu = p01.Stutendt("adsf", 19)
stu.say()
p01.sayHi()