import sys
# print(type(sys.path))
# print(sys.path)

for i in sys.path:
    print(i)