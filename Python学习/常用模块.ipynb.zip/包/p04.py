from p01 import Stutendt, sayHi
stu = Stutendt()
stu.say()

sayHi()