def getName():
    print("this is p01 ")
class Stusent():
    def __init__(self):
        self.name = "ads"
        self.age = 10
    def say(self):
        print("say Hi")
